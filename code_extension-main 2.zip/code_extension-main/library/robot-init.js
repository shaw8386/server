lottie.loadAnimation({
  container: document.getElementById('lottie-character'),
  renderer: 'svg',
  loop: true,
  autoplay: true,
  path: 'images/robot.json'
});