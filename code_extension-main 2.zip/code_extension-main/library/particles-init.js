tsParticles.load("particles-js", {
  background: {
    color: { value: "#0d47a1" }
  },
  particles: {
    number: { value: 40 },
    size: { value: 3 },
    move: { enable: true, speed: 1 },
    opacity: { value: 0.5 },
    links: { enable: true },
    color: { value: "#ffffff" }
  }
});
